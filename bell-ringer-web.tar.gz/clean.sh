#!/bin/bash
rm -f bell-ringer bell-ringer-administrate
